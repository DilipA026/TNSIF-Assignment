package com.tnsif.day1;

public class Sample {

	public static void main(String[] args) {

    System.out.println("New Project created for testing purpose");

	}

}
