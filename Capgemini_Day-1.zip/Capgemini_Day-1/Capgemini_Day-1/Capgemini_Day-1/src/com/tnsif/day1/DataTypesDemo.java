package com.tnsif.day1;

public class DataTypesDemo {

	public static void main(String[] args) {
		
		int value1= 10/2; //integer division
		float value2 = 10/3;  //float 
		double value3 = 10d /6d; // double
		
		System.out.println("value 1 =" + value1);
		System.out.println("value 2=" +value2);
		System.out.println("value 3=" +value3);
		
		
		
		

	}

}
